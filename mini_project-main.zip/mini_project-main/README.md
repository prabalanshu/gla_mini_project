# mini_project
GLA Mini project
![image](https://github.com/codeingroom/mini_project/assets/57828021/d06d6186-5175-4f43-b7fc-b47d7981ab03)
![image](https://github.com/codeingroom/mini_project/assets/57828021/e465c4f2-596b-4dbf-a17e-cc8498a0e382)

